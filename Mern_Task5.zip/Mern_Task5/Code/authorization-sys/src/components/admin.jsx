// src/components/Admin.jsx
import React from 'react';

const Admin = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p>Welcome, Admin! You have full access to manage users and settings.</p>
    </div>
  );
};

export default Admin;
