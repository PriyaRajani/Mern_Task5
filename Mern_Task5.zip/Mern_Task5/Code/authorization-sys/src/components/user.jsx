// src/components/User.jsx
import React from 'react';

const User = () => {
  return (
    <div>
      <h1>User Dashboard</h1>
      <p>Welcome, User! You can view and edit your profile.</p>
    </div>
  );
};

export default User;
